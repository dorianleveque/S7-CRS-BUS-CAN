var classqfi___n_a_v =
[
    [ "qfi_NAV", "classqfi___n_a_v.html#a9534f8247e36f04879517a02948a9809", null ],
    [ "~qfi_NAV", "classqfi___n_a_v.html#a53d6ef77b02beaa0198325695c24a634", null ],
    [ "reinit", "classqfi___n_a_v.html#a1e0eceb8868f060101ebef68c6cfc0b7", null ],
    [ "resizeEvent", "classqfi___n_a_v.html#add5bd61691c7771af8842978a453e25f", null ],
    [ "setBearing", "classqfi___n_a_v.html#a6b6dfe30f68bb75bcda037d7e7620fb3", null ],
    [ "setCourse", "classqfi___n_a_v.html#a661b3e0f017ad04cb68b9506f9535c7f", null ],
    [ "setDeviation", "classqfi___n_a_v.html#a90f2df3f334d78ea67289f346faaafe4", null ],
    [ "setDistance", "classqfi___n_a_v.html#a2913fbd47f0a85c1e33bd14f9ed37d46", null ],
    [ "setHeading", "classqfi___n_a_v.html#af0b0b051ccab84c34f25b1f9b5f3ef78", null ],
    [ "setHeadingBug", "classqfi___n_a_v.html#a24f190347c313e041499596db8bb3920", null ],
    [ "update", "classqfi___n_a_v.html#a7c8e1863b0fd72c747a65cea21a3bdf3", null ]
];