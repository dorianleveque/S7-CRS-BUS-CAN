var qfi___p_f_d_8cpp =
[
    [ "M_PI", "qfi___p_f_d_8cpp.html#ae71449b1cc6e6250b91f539153a7a0d3", null ],
    [ "QFI_PFD_CPP", "qfi___p_f_d_8cpp.html#a3cfd1c52e9302233696c6aacddc13ff0", null ]
];