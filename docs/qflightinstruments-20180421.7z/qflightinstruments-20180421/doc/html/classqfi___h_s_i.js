var classqfi___h_s_i =
[
    [ "qfi_HSI", "classqfi___h_s_i.html#a41b11fb392c0b2471b6b45f74c3fc6b2", null ],
    [ "~qfi_HSI", "classqfi___h_s_i.html#ae4522f841c6a737e14d5bc606176f5a1", null ],
    [ "reinit", "classqfi___h_s_i.html#aa69ee2276560377d8beb79d06cc82ddc", null ],
    [ "resizeEvent", "classqfi___h_s_i.html#a55320942201fb533f900de64ab2032e2", null ],
    [ "setHeading", "classqfi___h_s_i.html#a39f9c0994b467269099afa4b97a7e97d", null ],
    [ "update", "classqfi___h_s_i.html#a6693e29815c07cd3e54adc793de7e4f7", null ]
];